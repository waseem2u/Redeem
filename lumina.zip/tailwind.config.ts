
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      screens: {},
      backgroundImage: {

        "header-bg": "url('/images/bg-header.svg')",
        
      },
      boxShadow: {},
      colors: {
        
        "black-indian" :" #121414",
      },
    },
  },
  plugins: [],
};
