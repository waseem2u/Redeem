import React from "react";
import CustomButton from "./CustomButton";

const Header = () => {
  return (
    <div className="section-size bg-header-bg xl:bg-header-bg md:min-h-[827px] bg-contain min-[290px]:bg-cover 2xl:bg-center bg-no-repea">
      <div className="flex justify-center items-center ">
        <h3 className="text-4xl text-center md:text-5xl font-normal items-center font-sans text-[#ffffff] mt-[74px]">
          Lumina Nights Festival 2024
        </h3>
      </div>
      <p className="text-center font-semibold text-xl text-[#ffffff] mt-[22px]">
        September 10-12, 2024
        <br />
        Radiance Park, New York City, NY
      </p>

      <div className="flex justify-center items-center flex-col  gap-[26px]">
        <p className="font-medium text-lg text-[#ffffff]  text-center leading-[27px] mt-[383px]">
          Illuminate your senses at the most electrifying festival of the
          year.Embark on a three-night journey where music, art, and technology
          intertwine to create an unforgettable experience.
        </p>
        <CustomButton children="Mint Your Exclusive Festival NFT Now!" />
      </div>
    </div>
  );
};

export default Header;
