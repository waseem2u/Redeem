import React from "react";
import CustomCard from "./CustomCard";

const Journey = () => {
  return (
    <div className="bg-[#121414]">
      <div className="flex justify-center items-center ">
        <h3 className="text-center text-4xl md:text-5xl font-normal items-center font-sans text-[#ffffff] mt-[74px]">
          Your VIP Journey Begins Here
        </h3>
      </div>
      <CustomCard />
    </div>
  );
};

export default Journey;
