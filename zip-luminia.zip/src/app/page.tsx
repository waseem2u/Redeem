import Header from "./components/Header";
import Journey from "./components/Journey";
import Navbar from "./components/Navbar";

export default function Home() {
  return (
    <div>
      <Navbar />
      <Header />
      <Journey />
    </div>
  );
}
