import React from "react";
import CustomCard from "./CustomCard";

const Journey = () => {
  return (
    <div className="bg-[#121414]">
      <div className="flex justify-center items-center w-full">
        <h3 className="text-2xl text-center md:text-5xl font-normal items-center font-sans text-[#ffffff] mt-[74px] w-[300px] md:w-auto leading-[36px]">
          Your VIP Journey Begins Here
        </h3>
      </div>
      <CustomCard />
    </div>
  );
};

export default Journey;
