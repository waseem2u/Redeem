import React from "react";
import CustomButton from "./CustomButton";

const Header = () => {
  return (
    <div className="section-size bg-header-bg xl:bg-header-bg md:min-h-[827px] bg-contain min-[290px]:bg-cover 2xl:bg-center bg-no-repea">
      <div className="flex justify-center items-center w-full">
        <h3 className="text-4xl text-center md:text-5xl font-normal items-center font-sans text-[#ffffff] mt-[74px] w-[300px] md:w-auto leading-[48px]">
          Lumina Nights Festival 2024
        </h3>
      </div>
      <p className="text-center font-semibold text-xl text-[#ffffff] mt-[22px]">
        September 10-12, 2024
        <br />
        Radiance Park, New York City, NY
      </p>

      <div className="flex justify-center items-center flex-col  gap-[26px]">
        <p className="xl:w-[814px] md:font-semibold font-medium text-base md:text-lg text-[#ffffff]  text-center leading-[27px] mt-[383px] ">
          Illuminate your senses at the most electrifying festival of the
          year.Embark on a three-night journey where music, art, and technology
          intertwine to create an unforgettable experience.
        </p>
        <CustomButton children="Mint Your Exclusive Festival NFT Now!" className="text-sm"/>
      </div>
      <div className="flex justify-end items-end">
        <img
          src="/logo/redeem-logo.svg"
          className="w-[91px] h-[52px] object-contain hidden md:block"
        />
      </div>
    </div>
  );
};

export default Header;
