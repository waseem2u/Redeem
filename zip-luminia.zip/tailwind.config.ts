
/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      screens: {},
      backgroundImage: {

        "header-bg": "url('/images/bg-header.svg')",
        "bg-simple": "url('/images/card-simple.svg')",
        "card-bg": "url('/images/bg-card.svg')",
        
      },
      boxShadow: {},
      colors: {
        
        "black-indian" :" #121414",
        "lite-smoke"   :"#E0E0E01A",
      },
    },
  },
  plugins: [],
};
